# -*- coding: utf-8 -*-
import sys
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
PY3 = sys.version_info[0] == 3
if PY3:
    from urllib.parse import unquote, quote_plus, unquote_plus, urlencode #python 3
else:    
    from urllib import unquote, quote_plus, unquote_plus, urlencode
from update import auto_update
import os
import re
try:
    import json
except:
    import simplejson as json
import base64
import zlib
import requests
plugin = sys.argv[0]
handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addonid = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')
translate = xbmcvfs.translatePath if PY3 else xbmc.translatePath
profile = translate(addon.getAddonInfo('profile')) if PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
home = translate(addon.getAddonInfo('path')) if PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
fanart_default = os.path.join(home, 'fanart.jpg')
next = os.path.join(home, 'icons','next_blue.png')
search_icon = os.path.join(home, 'icons','search.png')
dialog = xbmcgui.Dialog()



def route(f):
    action_f = f.__name__
    params_dict = {}
    param_string = sys.argv[2]
    if param_string:
        split_commands = param_string[param_string.find('?') + 1:].split('&')
        for command in split_commands:
            if len(command) > 0:
                if "=" in command:
                    split_command = command.split('=')
                    key = split_command[0]
                    value = split_command[1]
                    try:
                        key = unquote_plus(key)
                    except:
                        pass
                    try:
                        value = unquote_plus(value)
                    except:
                        pass
                    params_dict[key] = value
                else:
                    params_dict[command] = ""
    action = params_dict.get('action')
    if action is None and action_f == 'main':
        f()
    elif action == action_f:
        f(params_dict)

def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string

def search():
    vq = get_search_string(heading='Digite a pesquisa', message="")        
    if ( not vq ): return False
    return vq

def req(url):
    try:
        html = requests.get(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'}).content
    except:
        html = ''
    try:
        invertido = html[::-1]
        base64_decode = base64.b64decode(invertido)
        zlib_decode = zlib.decompress(base64_decode)
        html = zlib_decode
    except:
        pass
    try:
        html = html.decode('utf-8')
    except:
        pass 
    return html

def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, iconimage, time, sound=sound)




def SetView(name):
    if name == 'Wall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(500)')
        except:
            pass
    if name == 'List':
        try:
            xbmc.executebuiltin('Container.SetViewMode(50)')
        except:
            pass
    if name == 'Poster':
        try:
            xbmc.executebuiltin('Container.SetViewMode(51)')
        except:
            pass
    if name == 'Shift':
        try:
            xbmc.executebuiltin('Container.SetViewMode(53)')
        except:
            pass
    if name == 'InfoWall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(54)')
        except:
            pass
    if name == 'WideList':
        try:
            xbmc.executebuiltin('Container.SetViewMode(55)')
        except:
            pass
    if name == 'Fanart':
        try:
            xbmc.executebuiltin('Container.SetViewMode(502)')
        except:
            pass


def get_url(params):
    if params:
        url = '%s?%s'%(plugin, urlencode(params))
    else:
        url = ''
    return url


def item(params,folder=True):
    u = get_url(params)
    if not u:
        u = ''
    name = params.get("name")
    if name:
        name = name
    else:
        name = 'Unknow'
    iconimage = params.get("iconimage")
    if not iconimage:
        iconimage = ''
    fanart = params.get("fanart")
    if not fanart:
        fanart = fanart_default
    description = params.get("description")
    if not description:
        description = ''           
    playable = params.get("playable")
    liz = xbmcgui.ListItem(name)
    liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    if params.get("media"):
        liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})                                                  
    if playable:
        if playable == 'true':
            liz.setProperty('IsPlayable', 'true')
    try:
        contextMenu = []
        try:
            desc = description.encode('utf-8', 'ignore')
        except:
            desc = description
        desc = description
        if PY3:
            contextMenu.append(('Informacao','RunPlugin(%s?action=viewdesc&description=%s)'%(sys.argv[0], quote_plus(desc))))
        else:
            contextMenu.append(('Informacao','XBMC.RunPlugin(%s?action=viewdesc&description=%s)'%(sys.argv[0], quote_plus(desc))))
        liz.addContextMenuItems(contextMenu)
    except:
        pass
    ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
    return ok

def chunks(lista, n):
    for i in range(0, len(lista), n):
        yield lista[i:i + n]  


def getitems(items,fanart,page,tipo,search,quant,url):
    check = []
    if items:
        if tipo == 'movie' and not search:
            array = list(chunks(items, quant))
            total_page = int(len(array))
            select_array = array[page - 1 if total_page > 1 else 0]            
            try:
                select_array = array[page - 1 if total_page > 1 else 0]
            except:
                select_array = []
        else:
            total_page = 0
            select_array = items
        if select_array:
            for i in select_array:
                try:
                    name = re.findall('<title>(.*?)</title>', i,flags=re.MULTILINE|re.DOTALL)[0]
                    if name == None or name == '':
                        name = 'nome desconhecido'
                except:
                    name = 'nome desconhecido'
                name = name.replace(';', '')
                try:
                    name = name.encode('utf-8', 'ignore')
                except:
                    pass                
                try:
                    thumbnail = re.findall('<thumbnail>(.*?)</thumbnail>', i,flags=re.MULTILINE|re.DOTALL)[0]
                    if thumbnail == None:
                        thumbnail = ''
                except:
                    thumbnail = ''
                try:
                    keys = re.findall('<keys>(.*?)</keys>', i,flags=re.MULTILINE|re.DOTALL)[0]
                    if keys == None:
                        keys = ''
                except:
                    keys = ''                     
                try:
                    fanart_novo = re.findall('<fanart>(.*?)</fanart>', i,flags=re.MULTILINE|re.DOTALL)[0]
                    if fanart_novo == None:
                        fanart_novo = ''
                except:
                    fanart_novo = ''
                if not fanart_novo:
                    fanArt = fanart
                else:
                    fanArt = fanart_novo
                try:
                    desc = re.findall('<info>(.*?)</info>', i,flags=re.MULTILINE|re.DOTALL)[0]
                    if desc == None:
                        desc = ''
                except:
                    desc = ''
                try:
                    desc = desc.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    link = re.findall('<link>(.*?)</link>', i,flags=re.MULTILINE|re.DOTALL)[0]
                    if link == None:
                        link = ''
                except:
                    link = ''
                try:
                    if search:
                        if not search.lower() in keys.lower():
                            pass
                        else:
                            check.append('tem')
                            item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'action': 'playitem', 'url': link, 'description': desc},folder=False)
                    else:
                        check.append('tem')
                        item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'action': 'playitem', 'url': link, 'description': desc},folder=False)
                except:
                    infoDialog('[COLOR red]Erro ao Carregar o menu %s[/COLOR]'%name, iconimage='ERROR', time=30, sound=False)
            if tipo == 'movie' and not search:
                if int(page) + 1 <= total_page and total_page > 1:
                    item({'name': 'Pagina ' + str(int(page) + 1) + ' de '+str(total_page), 'fanart': fanArt, 'action': 'getData', 'tipo': tipo, 'url': url, 'page': str(int(page) + 1),'iconimage': next},folder=True)                    
        else:
            infoDialog('[COLOR red]sem items[/COLOR]', iconimage='ERROR', time=30, sound=False)
    else:
        infoDialog('[COLOR red]items vazios[/COLOR]', iconimage='ERROR', time=30, sound=False)
    return check

@route
def getData(param):
    url = param.get('url')
    tipo = param.get('tipo')
    fanart = param.get('fanart')
    if not fanart:
        fanart = ''    
    search = param.get('search')
    if not search:
        search = ''
    try:
        page = int(param.get('page'))
    except:
        page = 1
    quant = 2
    data = req(url)
    check = []
    if data:
        if tipo == 'movie':
            xbmcplugin.setContent(handle, 'movies')
        else:
            xbmcplugin.setContent(handle, 'tvshows')
        channels = re.findall('<channels>(.+?)</channels>',data,flags=re.MULTILINE|re.DOTALL)
        channel = re.findall('<channel>(.*?)</channel>', data,flags=re.MULTILINE|re.DOTALL)
        items = re.findall('<item>(.*?)</item>', data,flags=re.MULTILINE|re.DOTALL)
        if len(channels) >0:
            if channel:
                if tipo == 'tvshow' and not search:
                    array = list(chunks(channel, quant))
                    total_page = int(len(array))
                    try:
                        select_array = array[page - 1 if total_page > 1 else 0]
                    except:
                        select_array = []
                else:
                    total_page = 0
                    select_array = channel
                if select_array:
                    for channel in select_array:
                        linkedUrl=''
                        try:
                            linkedUrl = re.findall('<externallink>(.*?)</externallink>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                        except: pass
                        try:
                            name = re.findall('<name>(.*?)</name>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                        except:
                            name = 'nome desconhecido'
                        try:
                            name = name.encode('utf-8', 'ignore')
                        except:
                            pass
                        try:
                            thumbnail = re.findall('<thumbnail>(.*?)</thumbnail>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if thumbnail == None:
                                thumbnail = ''
                        except:
                            thumbnail = ''
                        try:
                            keys = re.findall('<keys>(.*?)</keys>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if keys == None:
                                keys = ''
                        except:
                            keys = ''                            
                        try:
                            fanart_novo = re.findall('<fanart>(.*?)</fanart>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if fanart_novo == None:
                                fanart_novo = ''
                        except:
                            fanart_novo = ''
                        if not fanart_novo:
                            fanArt = fanart
                        else:
                            fanArt = fanart_novo
                        try:
                            desc = re.findall('<info>(.*?)</info>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if desc == None:
                                desc = ''
                        except:
                            desc = ''
                        try:
                            desc = desc.encode('utf-8', 'ignore')
                        except:
                            pass
                        try:
                            if linkedUrl=='':
                                item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'description': desc},folder=True)
                            else:
                                if search:
                                    if not search.lower() in keys.lower():
                                        pass
                                    else:
                                        check.append('tem')
                                        item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'action': 'getData', 'tipo': tipo,'url': linkedUrl, 'description': desc},folder=True)
                                else:
                                    check.append('tem')
                                    item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'action': 'getData', 'tipo': tipo,'url': linkedUrl, 'description': desc},folder=True)
                        except:
                            infoDialog('[COLOR red]Erro ao Carregar o menu %s[/COLOR]'%name, iconimage='ERROR', time=30, sound=False)
                    if tipo == 'tvshow' and not search:
                        if int(page) + 1 <= total_page and total_page > 1:
                            item({'name': 'Pagina ' + str(int(page) + 1) + ' de '+str(total_page), 'fanart': fanArt, 'action': 'getData', 'tipo': tipo, 'url': url, 'page': str(int(page) + 1),'iconimage': next},folder=True)
        elif len(items) > 0:
            check = getitems(items,fanart,page,tipo,search,quant,url)
        else:
            infoDialog('[COLOR red]nenhuma estrutura disponivel[/COLOR]', iconimage='ERROR', time=30, sound=False)
    else:
        infoDialog('[COLOR red]sem dados[/COLOR]', iconimage='ERROR', time=30, sound=False)
    if check:
        xbmcplugin.endOfDirectory(handle)
        SetView('Wall')
    else:
        infoDialog('Nada encontrado', iconimage='INFO', time=30, sound=False)


def getData2(param):
    url = param.get('url')
    tipo = param.get('tipo')
    fanart = param.get('fanart')
    if not fanart:
        fanart = ''    
    search = param.get('search')
    if not search:
        search = ''
    try:
        page = int(param.get('page'))
    except:
        page = 1
    quant = 2
    data = req(url)
    check = []
    if data:
        if tipo == 'movie':
            xbmcplugin.setContent(handle, 'movies')
        else:
            xbmcplugin.setContent(handle, 'tvshows')
        channels = re.findall('<channels>(.+?)</channels>',data,flags=re.MULTILINE|re.DOTALL)
        channel = re.findall('<channel>(.*?)</channel>', data,flags=re.MULTILINE|re.DOTALL)
        items = re.findall('<item>(.*?)</item>', data,flags=re.MULTILINE|re.DOTALL)
        if len(channels) >0:
            if channel:
                if tipo == 'tvshow' and not search:
                    array = list(chunks(channel, quant))
                    total_page = int(len(array))
                    try:
                        select_array = array[page - 1 if total_page > 1 else 0]
                    except:
                        select_array = []
                else:
                    total_page = 0
                    select_array = channel
                if select_array:
                    for channel in select_array:
                        linkedUrl=''
                        try:
                            linkedUrl = re.findall('<externallink>(.*?)</externallink>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                        except: pass
                        try:
                            name = re.findall('<name>(.*?)</name>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                        except:
                            name = 'nome desconhecido'
                        try:
                            name = name.encode('utf-8', 'ignore')
                        except:
                            pass
                        try:
                            thumbnail = re.findall('<thumbnail>(.*?)</thumbnail>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if thumbnail == None:
                                thumbnail = ''
                        except:
                            thumbnail = ''
                        try:
                            keys = re.findall('<keys>(.*?)</keys>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if keys == None:
                                keys = ''
                        except:
                            keys = ''                            
                        try:
                            fanart_novo = re.findall('<fanart>(.*?)</fanart>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if fanart_novo == None:
                                fanart_novo = ''
                        except:
                            fanart_novo = ''
                        if not fanart_novo:
                            fanArt = fanart
                        else:
                            fanArt = fanart_novo
                        try:
                            desc = re.findall('<info>(.*?)</info>', channel,flags=re.MULTILINE|re.DOTALL)[0]
                            if desc == None:
                                desc = ''
                        except:
                            desc = ''
                        try:
                            desc = desc.encode('utf-8', 'ignore')
                        except:
                            pass
                        try:
                            if linkedUrl=='':
                                item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'description': desc},folder=True)
                            else:
                                if search:
                                    if not search.lower() in keys.lower():
                                        pass
                                    else:
                                        check.append('tem')
                                        item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'action': 'getData', 'tipo': tipo,'url': linkedUrl, 'description': desc},folder=True)
                                else:
                                    check.append('tem')
                                    item({'name': name, 'iconimage': thumbnail, 'fanart': fanArt, 'action': 'getData', 'tipo': tipo,'url': linkedUrl, 'description': desc},folder=True)
                        except:
                            infoDialog('[COLOR red]Erro ao Carregar o menu %s[/COLOR]'%name, iconimage='ERROR', time=30, sound=False)
                    if tipo == 'tvshow' and not search:
                        if int(page) + 1 <= total_page and total_page > 1:
                            item({'name': 'Pagina ' + str(int(page) + 1) + ' de '+str(total_page), 'fanart': fanArt, 'action': 'getData', 'tipo': tipo, 'url': url, 'page': str(int(page) + 1),'iconimage': next},folder=True)
        elif len(items) > 0:
            check = getitems(items,fanart,page,tipo,search,quant,url)
        else:
            infoDialog('[COLOR red]nenhuma estrutura disponivel[/COLOR]', iconimage='ERROR', time=30, sound=False)
    else:
        infoDialog('[COLOR red]sem dados[/COLOR]', iconimage='ERROR', time=30, sound=False)
    if check:
        xbmcplugin.endOfDirectory(handle)
        SetView('Wall')
    else:
        infoDialog('Nada encontrado', iconimage='INFO', time=30, sound=False)


@route
def pesquisar(param):
    url = param.get('url')
    tipo = param.get('tipo')
    s = search()
    if s:
        getData2({'url': url,'tipo': tipo, 'search': s})


@route
def main():
    auto_update()   
    xbmcplugin.setContent(handle, 'movies')
    item({'name': 'Filmes', 'iconimage': '', 'fanart': '', 'action': 'filmes', 'description': ''},folder=True)
    item({'name': 'Verificar update', 'iconimage': '', 'fanart': '', 'action': 'verificaupdate', 'description': ''},folder=True)
    xbmcplugin.endOfDirectory(handle)
    SetView('WideList')

@route
def verificaupdate(param):
    from update import auto_update, update_version
    auto_update()
    ver = 'última versão: %s'%update_version
    dialog.ok(addonname, ver)


@route
def filmes(param):
    xbmcplugin.setContent(handle, 'movies')
    item({'name': 'Pesquisar Filme', 'iconimage': '', 'fanart': '', 'action': 'pesquisar', 'tipo': 'movie','url': 'https://onepod.inrupt.net/acesso/fastp/filmes.txt', 'description': '', 'iconimage': search_icon},folder=True)
    item({'name': 'FILMES', 'iconimage': '', 'fanart': '', 'action': 'getData', 'tipo': 'movie','url': 'https://onepod.inrupt.net/acesso/fastp/filmes.txt', 'description': ''},folder=True)
    xbmcplugin.endOfDirectory(handle)
    SetView('WideList')

@route
def viewdesc(param):
    description = param.get('description')
    dialog.textviewer('Informação', description)    


@route
def playitem(param):
    name = param.get('name')
    url = param.get('url')
    iconimage = param.get('iconimage')
    if not iconimage:
        iconimage = ''
    fanart = param.get('fanart')
    if not fanart:
        fanart = ''
    description = param.get('description')
    if not description:
        description = ''
    liz = xbmcgui.ListItem(name)
    liz.setPath(url)
    liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage})
    liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description})
    xbmc.Player().play(item=url, listitem=liz)